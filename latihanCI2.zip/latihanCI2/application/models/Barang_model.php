<?php 

class Barang_model extends CI_Model {

    function insert_data($data){
        $this->db->insert("barang", $data);
    }

    function fetch_data(){
        $query = $this->db->query("select * from barang order by id desc;");

        return $query;
    }
    
    function fetch_single_data($id){
        $this->db->where("id", $id);
        $query = $this->db->get("barang");

        return $query;
    }

    function update_data($data){
        $this->db->where("id", $data['id']);
        $this->db->update("barang", $data);
    }
}

?>