<?php 

class Cetak_model extends CI_Model {
    function fetch_laporan($bulan, $tahun){
        $query = $this->db->query("select *,
        @no := @no + 1 as no
        from penjualan_detail a
        left outer join barang b on a.id_barang = b.id
        left outer join penjualan c on a.id_penjualan = c.id
        cross join (select @no := 0) no
        where month(tgl_penjualan) = ".$bulan. " and year(tgl_penjualan) = ". $tahun);
        return $query;
    }
}

?>