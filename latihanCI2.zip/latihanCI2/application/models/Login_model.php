<?php 

class Login_model extends  CI_Model {

    function login($username, $password){
        $this->db->where('username', $username);
        $this->db->where('password', $password);

        $query = $this->db->get('user');

        if($query->num_rows() > 0){
            return true;
        }else{
            return false;
        }
    }

    function register($data){
        $this->db->insert("user", $data);
    }

}

?>