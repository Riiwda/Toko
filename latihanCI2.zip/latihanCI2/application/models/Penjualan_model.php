<?php 

class Penjualan_model extends  CI_Model {

    function fetch_data(){
        $query = $this->db->query("SELECT * FROM penjualan order by id desc");
        return $query;
    }
    function fetch_data_barang(){
        $query = $this->db->query("SELECT * FROM barang");
        return $query;
    }

    function insert_data($data){
        $this->db->insert("penjualan", $data);
    }
    function update_data($data){
        $this->db->where("id", $data['id']);
        $this->db->update("penjualan", $data);
    }

    function insert_data_detail($data){
        $this->db->insert("penjualan_detail", $data);
    }

    function fetch_data_detail(){
        $query = $this->db->query("select a.*, b.nama, b.harga_satuan from penjualan_detail a
        left outer join barang b on a.id_barang = b.id order by id desc");
        return $query;
    }

    function update_data_detail($data){
        $this->db->where("id", $data['id']);
        $this->db->update("penjualan_detail", $data);
    }

    function delete_data_detail($id){
        $this->db->where("id", $id);
        $this->db->delete("penjualan_detail");
    }
    
}

?>