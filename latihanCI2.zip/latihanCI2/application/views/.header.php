<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>

    <link rel="stylesheet" href="<?=base_url()?>assets/bootstrap400/css/bootstrap.css">
    <link rel="stylesheet" href="<?=base_url()?>assets/font-awesome/css/all.css">
    <link rel="stylesheet" href="<?=base_url()?>assets/bootstrap4-editable/css/bootstrap-editable.css">

   
    <script src="<?=base_url()?>assets/jquery/js/jquery-3.3.1.min.js"></script>
    <script src="<?=base_url()?>assets/jquery/js/jquery.mask.js"></script>
    <script src="<?=base_url()?>assets/popper/js/popper.min.js"></script>
    <script src="<?=base_url()?>assets/bootstrap400/js/bootstrap.min.js"></script>
    <script src="<?=base_url()?>assets/bootstrap4-editable/js/bootstrap-editable.js"></script>
    <script src="<?=base_url()?>assets/bootstrap4-editable/js/bootstrap-editable.min.js"></script>
</head>
<body>