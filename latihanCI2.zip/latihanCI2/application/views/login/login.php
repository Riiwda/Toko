<div class="container">
    <?php 
        
        if($this->uri->segment(2) == "registered"){
            echo "<p class='text-success'>Kamu telah terdaftar</p>";
        }
    ?>
    <form method="post" action="<?php echo base_url(); ?>login/login_validation">
        <div class="form-group">
            <label for="username">Username</label>
            <input type="text" name="username" id="username" class="form-control" />
            <span class="text-danger"><?php echo form_error('username'); ?></span>
        </div>
        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" name="password" id="password" class="form-control" />
            <span class="text-danger"><?php echo form_error('password'); ?></span>
        </div>
        <div class="form-group">
            <button type="submit" name="submit" class="btn btn-info">Login</button>
            <?php 
                echo $this->session->flashdata('error');
            ?>
        </div>
        <a href="<?php echo base_url() ?>login/register">Registrasi</a>
    </form>
</div>