<div class="container">
    
    <h3 align="center">Update Data Barang</h3>
    <?php echo form_open_multipart('barang/update');?>
        <?php 
            if(isset($barang)){
                $row = $barang->row();

        ?>
        <input type="hidden" name="id" class="form-control" value="<?php echo $row->id ?>" />
        <div class="form-group">
            <label>Nama Barang</label>
            <input type="text" name="nama_barang" class="form-control" value="<?php echo $row->nama ?>" />
            <span class="text-danger"><?php echo form_error("nama_barang"); ?><span>
        </div>
        <div class="form-group">
            <label>Harga Barang</label>
            <input type="text" name="harga_barang" class="form-control" value="<?php echo $row->harga_satuan ?>"/>
            <span class="text-danger"><?php echo form_error("harga_barang"); ?><span>
        </div>
        <div class="form-group">
            <label>Keterangan Barang</label>
            <textarea class="form-control" name="keterangan_barang" id="keterangan_barang" cols="30" rows="5"><?php echo $row->keterangan ?></textarea>
            <span class="text-danger">
            <?php echo form_error("keterangan_barang"); ?><span>
        </div>
        <div class="form-group">
            <label for="exampleFormControlFile1">Upload Gambar</label>
            <input type="file" class="form-control-file" id="upload_image" name="upload_image">
        </div>
        <div class="form-group">
            <button type="submit" name="submit" class="btn btn-info">Submit</button>
        </div>
        <?php
            }
        ?>

    </form>
</div>