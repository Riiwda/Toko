<div class="container">
    <h3 align="center">Show all data</h3>
    <div class="table-responsive">
        <?php 
        
        if($this->uri->segment(2) == "inserted"){
            echo "<p class='text-success'>Data Inserted</p>";
        }elseif($this->uri->segment(2) == "updated"){
            echo "<p class='text-success'>Data Updated</p>";
        }
        ?>
        
        <a href="<?php echo base_url()?>barang/add_form"><button class="btn btn-primary">
        <i class="fas fa-plus"></i> Tambah Data</button>
        </a>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Gambar</th>
                    <th>Nama Barang</th>
                    <th>Harga Satuan</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                
                    if($fetch_data->num_rows() > 0){
                        foreach($fetch_data->result() as $row){
                ?>
                    <tr>
                        <td><?php echo $row->id ?></td>
                        <td>
                        <?php if(!empty($row->gambar)){ ?>
                            <img src="<?php echo base_url() ?>/uploads/<?php echo $row->gambar ?>" alt="<?php echo $row->nama ?>" height="42" width="42">
                        <?php
                        }else{ ?>
                            <span class="text-danger">Tak ada gambar</span>
                        <?php
                        } ?>
                        
                        <td><?php echo $row->nama ?></td>
                        <td><?php echo $row->harga_satuan ?></td>
                        <td>
                            <a href="<?php echo base_url() ?>barang/update_form/<?php echo $row->id ?>"><i class="fas fa-edit"></i></a> 
                            <!-- <a href="<?php echo base_url() ?>barang/delete/<?php echo $row->id ?>" OnClick = "return confirm('Apa anda yakin ingin mendelete ini?');"><i class="fas fa-trash"></i></a> -->
                        </td>
                    </tr>
                <?php
                        }
                    }else{
                ?>
                    <tr>
                        <td colspan="3">No Data Found</td>
                    </tr>
                <?php
                    }

                ?>
            </tbody>
        </table>
    </div>
</div>
<script>


</script>