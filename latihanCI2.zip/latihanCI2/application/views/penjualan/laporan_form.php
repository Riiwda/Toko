<div class="container">
    <h3 align="center">Laporan Penjualan</h3>
    <form method="post" action="<?=base_url()?>Cetak/cetak_laporan">
        
        <div class="form-group">
            <label>Bulan</label>
            <select class="form-control" name="bulan">
                    <option value="0">Pilih Bulan</option>
                    <option value="1">Januari</option>
                    <option value="2">Febuari</option>
                    <option value="3">Maret</option>
                    <option value="4">April</option>
                    <option value="5">Mei</option>
                    <option value="6">Juni</option>
                    <option value="7">Juli</option>
                    <option value="8">Agustus</option>
                    <option value="9">September</option>
                    <option value="10">Oktober</option>
                    <option value="11">November</option>
                    <option value="12">Desember</option>
            </select>
        </div>
        <div class="form-group">
            <label>Harga Barang</label>
            <select class="form-control" name="tahun">
                <option value="2019">2019</option>
            </select>
        </div>
        <div class="form-group">
            <button type="submit" name="submit" class="btn btn-info">Submit</button>
        </div>

    </form>
</div>