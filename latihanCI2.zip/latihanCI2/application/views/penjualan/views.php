<div class="container">
    <h3 align="center">Penjualan</h3>
    <div class="table-responsive">
    <?php 
    
    if($this->uri->segment(2) == "inserted"){
        echo "<p class='text-success'>Data Inserted</p>";
    }elseif($this->uri->segment(2) == "updated"){
        echo "<p class='text-success'>Data Updated</p>";
    }
    ?>
        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter">
        <i class="fas fa-plus"></i> Tambah Penjualan
        </button>
        <a class="btn btn-primary" href="<?=base_url()?>penjualan/laporan_form">
        <i class="fas fa-print"></i>Cetak Laporan
        </a>

        <!-- Modal -->
        <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <form method='post' action='<?=base_url()?>penjualan/add'>
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalCenterTitle">Tambah Penjualan</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                                <div class='form-group '>
                                    <label>Tanggal Penjualan</label>
                                    <input type='date' name='tgl_penjualan' class='form-control' />
                                    <span class='text-danger'><span>
                                </div>
                        </div>
                        <div class="modal-footer">
                            <button type='submit' id='submit' name='submit' class='btn btn-success'>Submit</button>
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="table-responsive-lg">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th></th>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>Total Penjualan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    if($fetch_data->num_rows() > 0){
                        $no = 1;
                        foreach($fetch_data->result() as $row){
                    ?>
                        <tr>
                            <td><a data-toggle="collapse" href="#collapse<?=$no;?>" id="detail" role="button" aria-expanded="false" aria-controls="collapseExample"><i class="fas fa-plus"></i></a>
                            </td>
                            <td><?=$no ?></td>
                            <td><a class="tgl_penjualan" data-pk="<?=$row->id?>" id="<?=$row->id ?>" data-title="Masukkan tgl penjualan"><?=$row->tgl_penjualan?></a></td>
                            <td><?=$row->total_penjualan?></td>
                        </tr>
                        <tr>
                            <td colspan="4">
                            
                                <div class="collapse" id="collapse<?=$no;?>">
                                <div class="table-responsive-lg">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>no</th>
                                                <th>Nama Barang</th>
                                                <th>Harga Satuan</th>
                                                <th>Jumlah Barang</th>
                                                <th>Sub Total</th>
                                                <th>Aksi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php 
                                            $no_detail = 1;
                                            foreach($fetch_data_detail->result() as $detail){
                                                if($row->id == $detail->id_penjualan){
                                                    ?>
                                                    <tr>
                                                        <td><?=$no_detail?></td>
                                                        <td><?=$detail->nama?></td>
                                                        <td><?=$detail->harga_satuan?></td>
                                                        <td><?=$detail->jumlah_barang?> </td>
                                                        <td><?=$detail->sub_total?></td>
                                                        <td><a href="#" data-toggle="modal" data-target="#ModalDetailEdit" data-id="<?=$detail->id?>" data-barang="<?=$detail->id_barang?>" data-jumlah="<?=$detail->jumlah_barang?>" data-penjualan="<?=$detail->id_penjualan?>" class="EditDetail"><i class="fas fa-edit"></i></a>
                                                            <a href="<?=base_url()?>penjualan/delete_detail/<?=$detail->id?>" OnClick = "return confirm('Apa anda yakin ingin mendelete ini?');"><i class="fas fa-trash"></i></a>
                                                        </td>
                                                    </tr>
                                                    <?php
                                                $no_detail++;}
                                                ?>
                                                <?php
                                            }
                                            
                                            ?>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <td colspan="6"><a href="#" data-toggle="modal" data-target="#ModalDetailAdd" data-penjualan-id="<?=$row->id?>" class="AddDetail"><i class="fas fa-plus"></i></a></td>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                                </div>
                            </td>
                        </tr>
                        
                    <?php
                    $no++;
                        }
                    }else{
                    ?>
                        <tr>
                            <td colspan="4"><span class="text-danger">No Data Found</span></td>
                        </tr>
                    <?php
                    }
                    ?>
                </tbody>
            </table>

            <!-- Modal -->
            <div class="modal fade" id="ModalDetailAdd" tabindex="-1" role="dialog" aria-labelledby="ModalDetailAddTitle" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <form method='post' action='<?=base_url()?>penjualan/add_detail'>
                            <div class="modal-header">
                                <h5 class="modal-title" id="ModalDetailAddTitle">Tambah Penjualan Detail</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                    <div class='form-group '>
                                        <label>Barang</label>

                                        <input type="hidden" name="id_penjualan" id="id_penjualan">
                                        <select name="barang" id="barang" class='form-control'>
                                            <option value="0">pilih Barang</option>
                                            <?php foreach($fetch_data_barang->result() as $barang){ ?>
                                            <option value="<?=$barang->id?>"><?=$barang->nama?>, Harga satuan : <?=$barang->harga_satuan?></option>
                                            <?php } ?>
                                        </select>
                                        <span class='text-danger'><span>
                                    </div>
                                    <div class='form-group '>
                                        <label>Jumlah Beli</label>
                                        <input type='number' name='jumlah_beli' class='form-control' />
                                        <span class='text-danger'><span>
                                    </div>
                            </div>
                            <div class="modal-footer">
                                <button type='submit' id='submit' name='submit' class='btn btn-success'>Submit</button>
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Modal Edit -->
            <div class="modal fade" id="ModalDetailEdit" tabindex="-1" role="dialog" aria-labelledby="ModalDetailEditTitle" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <form method='post' action='<?=base_url()?>penjualan/update_detail'>
                            <div class="modal-header">
                                <h5 class="modal-title" id="ModalDetailEditTitle">Tambah Penjualan Detail</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <input type="hidden" name="id_detail" id="id_detail">
                                <div class='form-group '>
                                    <label>Barang</label>
                                    <select name="barang" id="barang" class='form-control'>
                                        <option value="0">pilih Barang</option>
                                        <?php foreach($fetch_data_barang->result() as $barang){ ?>
                                        <option value="<?=$barang->id?>"><?=$barang->nama?>, Harga satuan : <?=$barang->harga_satuan?></option>
                                        <?php } ?>
                                    </select>
                                    <span class='text-danger'><span>
                                </div>
                                <div class='form-group '>
                                    <label>Jumlah Beli</label>
                                    <input type='number' name='jumlah' id="jumlah" class='form-control' />
                                    <span class='text-danger'><span>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type='submit' id='submit' name='submit' class='btn btn-success'>Submit</button>
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>


            
        </div>
    </div>
</div>
<script>
$(document).ready(function() {
    //barang look up
    let barang = [];
    let sb_barang = document.getElementById('barang');
    for(var i = 0; i<sb_barang.options.length; i++){
        barang.push({
            value:sb_barang.options[i].value,
            text:sb_barang.options[i].text
            });
    }
    //turn to inline mode
    $.fn.editable.defaults.mode = 'inline';
    $.fn.editable.defaults.send = "always";

    //membuat edit inline di tgl penjualan
    $('.tgl_penjualan').editable({
        type: 'text',
        tpl: '<input type="text" class="mask form-control input-sm dd" style="padding-right: 24px;">',
        validate: function(value) {
            /*Add Ur validation logic and message here*/
            if ($.trim(value) == '') {return 'Perlu diisi!';}
        }
    });


    $('.tgl_penjualan').on('save', function(e, params){
    var fieldId = this.id;
        $('.tgl_penjualan').editable('submit', {
            success: function(response, config){
                $.ajax({
                    dataType: 'json',
                    type: 'POST',
                    url: '<?=base_url()?>penjualan/update',
                    data:{
                        id: fieldId,
                        tgl: $('#' + fieldId).editable('getValue')[fieldId]
                    }
                })
            },
            error: function(response, config){
                console.log('error');
            }
        });
    });

    $(document).on("focus", ".mask", function() {
        $(this).mask("0000-00-00");
    });


    //modal open value
    $(document).on("click", ".AddDetail", function(){
        let penjualan_id = $(this).data('penjualan-id');
        $("#id_penjualan").val(penjualan_id);
    });

    $('.EditDetail').click( function(){
        $('.modal-body #id_detail').val($(this).data('id'));
        $('.modal-body #barang').val($(this).data('barang'));
        $('.modal-body #jumlah').val($(this).data('jumlah'));
    });
});
</script>