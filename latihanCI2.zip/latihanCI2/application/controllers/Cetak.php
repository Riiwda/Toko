<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cetak extends CI_Controller {
    public function __construct()
	{
        parent :: __construct();
        
		$this->load->library("pagination");
        if($this->session->userdata('username') == ''){
            redirect(base_url() . 'login');
        }

        require_once APPPATH."third_party/opentbs/tbs/tbs_class.php";
        require_once APPPATH."third_party/opentbs/tbs/tbs_plugin_opentbs.php";
        
    }

    public function cetak_laporan(){
        $this->load->model("Cetak_model");
        $TBS = new clsTinyButStrong; // new instance of TBS
        $TBS->Plugin(TBS_INSTALL, OPENTBS_PLUGIN); // load the OpenTBS plugin

        switch($this->input->post('bulan')){
            case 1 :
                $bulan = 'Januari';
                break;
            case 2 :
                $bulan = 'Februari';
                break;
            case 3 :
                $bulan = 'Maret';
                break;
            case 4 :
                $bulan = 'April';
                break;
            case 5 :
                $bulan = 'Mei';
                break;
            case 6 :
                $bulan = 'Juni';
                break;
            case 7 :
                $bulan = 'Juli';
                break;
            case 8 :
                $bulan = 'Agustus';
                break;
            case 9 :
                $bulan = 'September';
                break;
            case 10 :
                $bulan = 'Oktober';
                break;
            case 11 :
                $bulan = 'November';
                break;
            case 12 :
                $bulan = 'Desember';
                break;
        }
        
        $data1 = array(
            'bulan'=>$bulan,
            'tahun'=>$this->input->post('tahun')
        );        
        $data2 = $this->Cetak_model->fetch_laporan($this->input->post('bulan'), $this->input->post('tahun'))->result();

        $template = APPPATH.'third_party/opentbs/template/cetak_laporan.odt';
        $TBS->LoadTemplate($template, OPENTBS_ALREADY_UTF8); // Also merge some [onload] automatic fields (depends of the type of document).

        $TBS->MergeField('data', $data1);
        $TBS->MergeBlock('$', $data2);

        // Define the name of the output file
        $nama_file = 'text.odf';
        // Output the result as a downloadable file (only streaming, no data saved in the server)
        $TBS->Show(OPENTBS_DOWNLOAD, $nama_file); // Also merges all [onshow] automatic fields.
        // Be sure that no more output is done, otherwise the download file is corrupted with extra data.
        redirect(base_url() . "penjualan");
    }
}