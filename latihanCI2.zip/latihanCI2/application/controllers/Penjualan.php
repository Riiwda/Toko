<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Penjualan extends CI_Controller {


	public function __construct()
	{
		parent :: __construct();   
		$this->load->helper(array('form', 'url'));
			//load the validation library
		$this->load->library('form_validation');
		$this->load->library("pagination");
        if($this->session->userdata('username') == ''){
            redirect(base_url() . 'login');
        }
    }

    public function index(){
        $this->load->model("penjualan_model");
        $this->load->view(".header.php");
        $this->load->view(".nav-admin.php");
        $data['fetch_data'] = $this->penjualan_model->fetch_data();
        $data['fetch_data_detail'] = $this->penjualan_model->fetch_data_detail();
        $data['fetch_data_barang'] = $this->penjualan_model->fetch_data_barang();
        $this->load->view("penjualan/views.php", $data);
        $this->load->view(".footer.php");
    }

    public function add(){
        $this->load->model("penjualan_model");
        $data = array(
            "tgl_penjualan"=>$this->input->post("tgl_penjualan"),
            "total_penjualan"=>''
        );
        $this->penjualan_model->insert_data($data);

        redirect(base_url() . "penjualan/inserted");
    }

    public function inserted(){
        $this->index();
    }

    public function update(){
        $this->load->model("penjualan_model");
        $data = array(
            "id"=>$this->input->post('id'),
            "tgl_penjualan"=>$this->input->post('tgl')
        );
        $this->penjualan_model->update_data($data);

        redirect(base_url() . "penjualan/updated");
    }

    public function updated(){
        $this->index();
    }
    public function add_detail(){
        $this->load->model("penjualan_model");
        $data = array(
            'id_barang'=>$this->input->post('barang'),
            'id_penjualan'=>$this->input->post('id_penjualan'),
            'jumlah_barang'=>$this->input->post('jumlah_beli')
        );
        $this->penjualan_model->insert_data_detail($data);

        redirect(base_url() . 'penjualan/added_detail');
    }

    public function added_detail(){
        $this->index();
    }

    public function update_detail(){
        $this->load->model("penjualan_model");
        $data = array(
            'id'=>$this->input->post('id_detail'),
            'id_barang'=>$this->input->post('barang'),
            'jumlah_barang'=>$this->input->post('jumlah')
        );
        $this->penjualan_model->update_data_detail($data);
        redirect(base_url() . 'penjualan/updated_detail');
    }
    public function updated_detail(){
        $this->index();
    }

    public function delete_detail(){
		$id = $this->uri->segment(3);

		$this->load->model("penjualan_model");
		$this->penjualan_model->delete_data_detail($id);
		redirect(base_url() . "penjualan/deleted_detail");
    }

    public function deleted_detail(){
        $this->index();
    }

    public function laporan_form(){
        $this->load->view('.header.php');
        $this->load->view('.nav-admin.php');
        $this->load->view('penjualan/laporan_form.php');
        $this->load->view('.footer.php');
    }

      
}