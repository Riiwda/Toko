<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Barang extends CI_Controller {


	public function __construct()
	{
		parent :: __construct();   
		$this->load->helper(array('form', 'url'));
			//load the validation library
		$this->load->library('form_validation');
		$this->load->library("pagination");
        if($this->session->userdata('username') == ''){
            redirect(base_url() . 'login');
        }
 	 }
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index(){
		$this->load->model("barang_model");
		$data["fetch_data"] = $this->barang_model->fetch_data();
		$this->load->view(".header.php");
		$this->load->view('.nav-admin.php');
		$this->load->view("barang/views", $data);
		$this->load->view(".footer.php");
	}

	public function add_form(){
		$this->load->view(".header.php");
		$this->load->view('.nav-admin.php');
		$this->load->view("barang/add_form", array('error' => ' ' ));
		$this->load->view(".footer.php");
	}

	public function add(){
		//load library upload
		$config['file_name'] = $this->input->post("nama_barang");
		$config['upload_path'] = './uploads/';
		$config['allowed_types'] = 'gif|jpg|jpeg|png';
		$config['max_size'] = 10000;

		$this->load->library('upload', $config);
		$this->upload->overwrite = true;

		$this->form_validation->set_rules("nama_barang", "Nama Barang", "required|alpha|max_length[30]");
		$this->form_validation->set_rules("harga_barang", "Harga Barang", "required|alpha_numeric|max_length[30]");
		$this->form_validation->set_rules("keterangan_barang", "Keterangan Barang", "required");

		if($this->form_validation->run()){
			if ( ! $this->upload->do_upload('upload_image')){
				$error = array('error' => $this->upload->display_errors());
	
				$this->load->view(".header.php");
				$this->load->view('.nav-admin.php');
				$this->load->view("barang/add_form", $error);
				$this->load->view(".footer.php");
			}else{
				$this->load->model("barang_model");
				$data = array(
					"nama"=>$this->input->post("nama_barang"),
					"harga_satuan"=>$this->input->post("harga_barang"),
					"gambar"=>$this->upload->data('file_name'),
					"keterangan"=>$this->input->post("keterangan_barang")
				);
	
				$this->barang_model->insert_data($data);
	
				redirect(base_url() . "barang/inserted");
			}
		}else{
			$this->add_form();
		}
	}

	public function inserted(){
		$this->index();
	}

	public function update_form($id){
		$id = $this->uri->segment(3);

		$this->load->model("barang_model");
		$data["barang"] = $this->barang_model->fetch_single_data($id);

		$this->load->view(".header.php");
		$this->load->view('.nav-admin.php');
		$this->load->view("barang/update_form", $data);
		$this->load->view(".footer.php");
	}

	public function update(){
		//load library upload
		$config['file_name'] = $this->input->post("nama_barang");
		$config['upload_path'] = './uploads/';
		$config['allowed_types'] = 'gif|jpg|png';
		$config['max_size'] = 10000;

		$this->load->library('upload', $config);
		$this->upload->overwrite = true;
		
		$this->form_validation->set_rules("nama_barang", "Nama Barang", "required|alpha");
		$this->form_validation->set_rules("harga_barang", "Harga Barang", "required|alpha_numeric");
		$this->form_validation->set_rules("keterangan_barang", "Keterangan Barang", "required");

		if($this->form_validation->run()){
			if ( ! $this->upload->do_upload('upload_image')){
				$error = array('error' => $this->upload->display_errors());
	
				redirect(base_url() . "barang/update_form/" . $this->input->post("id"));
			}else{
				$this->load->model("barang_model");
				$data = array(
					"id"=>$this->input->post("id"),
					"nama"=>$this->input->post("nama_barang"),
					"harga_satuan"=>$this->input->post("harga_barang"),
					"gambar"=>$this->upload->data('file_name'),
					"keterangan"=>$this->input->post("keterangan_barang")
				);
				$upload = array('upload_data' => $this->upload->data());
	
				$this->barang_model->update_data($data);
	
				redirect(base_url() . "barang/updated");
			}
				
		}else{
			redirect(base_url() . "barang/update_form/" . $this->input->post("id"));
		}
	}

	public function updated(){
		$this->index();
	}

	public function upload_form(){
		$id = $this->uri->segment(3);
		
		$this->load->model("barang_model");
		$data["barang"] = $this->barang_model->fetch_single_data($id);

		$this->load->view(".header.php");
		$this->load->view('.nav-admin.php');
		$this->load->view("barang/upload_form", $data);
		$this->load->view(".footer.php");
	}

}
