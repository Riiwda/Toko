<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {


	public function __construct()
  	{
        parent :: __construct();   
        $this->load->library('form_validation');
        $this->load->library('encryption');
        //$this->load->model('register_model');
    }

    function index(){
        $this->load->view('.header.php');
        $this->load->view('login/login');
        $this->load->view('.footer.php');
    }

    function register(){
        $this->load->view('.header.php');
        $this->load->view('login/register');
        $this->load->view('.footer.php');
    }
    
    function login_validation(){
            $this->form_validation->set_rules('username','Username', 'required');
            $this->form_validation->set_rules('password', 'Password', 'required');

            if($this->form_validation->run()){
                $username = $this->input->post('username');
                $password = md5($this->input->post('password'));
                $this->load->model('login_model');
                if($this->login_model->login($username, $password)){
                    $session_data = array(
                        'username' => $username
                    );
                    $this->session->set_userdata($session_data);
                    redirect(base_url() . 'login/enter');
                }else{
                    $this->session->set_flashdata('error', 'Invalid Username and Password');
                    redirect(base_url() . 'login');
                }
            }else{
                $this->index();
            }
    }

    function register_validation(){
        $this->form_validation->set_rules('username','Username', 'required|min_length[5]|max_length[12]|is_unique[user.username]');
        $this->form_validation->set_rules('password', 'Password', 'required');
        $this->form_validation->set_rules('confirm_password', 'Password Confirmation', 'required|matches[password]');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');

        if($this->form_validation->run()){
            $this->load->model("login_model");
            $data = array(
                "username"=>$this->input->post("username"),
                "password"=>md5($this->input->post("password")),
                "email"=>$this->input->post("email")
            );

            $this->login_model->register($data);
            redirect(base_url() . 'login/registered');
        }else{
            $this->register();
        }
    }

    function enter(){
        if($this->session->userdata('username') != ''){
            //echo '<h2>Welcome - ' . $this->session->userdata('username'). '</h2>';
            //echo '<label><a href="' . base_url() . 'login/logout">Logout</a></label>';
            redirect(base_url() . 'barang');
        }else{
            redirect(base_url() . 'login');
        }
    }

    function registered(){
        $this->index();
    }

    function logout(){
        $this->session->unset_userdata('username');
        redirect(base_url() . 'login');
    }
}
