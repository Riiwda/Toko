-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 09, 2019 at 05:45 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_ci`
--
CREATE DATABASE IF NOT EXISTS `db_ci` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `db_ci`;

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `hapus_barang` (IN `vharga` INT(11))  BEGIN
	DELETE FROM barang WHERE harga_satuan = vharga;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_barang` (IN `vnama` VARCHAR(255), IN `vharga` INT(11))  BEGIN
	INSERT INTO barang(nama, harga_satuan)
    VALUES(vnama, vharga);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `table_barang` ()  begin
	SELECT * FROM barang;
END$$

--
-- Functions
--
CREATE DEFINER=`root`@`localhost` FUNCTION `hello` (`x` VARCHAR(50)) RETURNS VARCHAR(255) CHARSET latin1 BEGIN
	RETURN concat('Hello ', x);
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `barang`
--

CREATE TABLE `barang` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) DEFAULT NULL,
  `harga_satuan` int(11) DEFAULT NULL,
  `gambar` varchar(255) DEFAULT NULL,
  `keterangan` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `barang`
--

INSERT INTO `barang` (`id`, `nama`, `harga_satuan`, `gambar`, `keterangan`) VALUES
(3, 'buku', 10000, NULL, NULL),
(4, 'pensil', 2000, NULL, NULL),
(5, 'penghapus', 2000, NULL, 'test test'),
(6, 'penggaris', 3000, '6.jpg', 'test test'),
(7, 'tipex', 2000, 'tipex.jpeg', 'test');

-- --------------------------------------------------------

--
-- Table structure for table `penjualan`
--

CREATE TABLE `penjualan` (
  `id` int(11) NOT NULL,
  `tgl_penjualan` date DEFAULT NULL,
  `total_penjualan` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `penjualan`
--

INSERT INTO `penjualan` (`id`, `tgl_penjualan`, `total_penjualan`) VALUES
(1, '2019-04-01', 10000),
(2, '2019-03-11', 6000),
(3, '2019-04-02', 3000);

-- --------------------------------------------------------

--
-- Table structure for table `penjualan_detail`
--

CREATE TABLE `penjualan_detail` (
  `id` int(11) NOT NULL,
  `id_barang` int(11) DEFAULT NULL,
  `id_penjualan` int(11) DEFAULT NULL,
  `jumlah_barang` int(11) DEFAULT NULL,
  `sub_total` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `penjualan_detail`
--

INSERT INTO `penjualan_detail` (`id`, `id_barang`, `id_penjualan`, `jumlah_barang`, `sub_total`) VALUES
(2, 5, 1, 3, '6000.00'),
(3, 5, 1, 2, '4000.00'),
(4, 5, 2, 3, '6000.00'),
(5, 6, 3, 1, '3000.00');

--
-- Triggers `penjualan_detail`
--
DELIMITER $$
CREATE TRIGGER `penjualan_detail_AFTER_DELETE` AFTER DELETE ON `penjualan_detail` FOR EACH ROW BEGIN
	DECLARE v_total_penjualan DECIMAL(10,2);
    SET v_total_penjualan = (select sum(sub_total) from penjualan_detail where id_penjualan = old.id_penjualan);
	update penjualan set total_penjualan = v_total_penjualan where id = old.id_penjualan;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `penjualan_detail_AFTER_INSERT` AFTER INSERT ON `penjualan_detail` FOR EACH ROW BEGIN
	DECLARE v_total_penjualan DECIMAL(10,2);
    SET v_total_penjualan = (select sum(sub_total) from penjualan_detail where id_penjualan = new.id_penjualan);
	update penjualan set total_penjualan = v_total_penjualan where id = new.id_penjualan;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `penjualan_detail_AFTER_UPDATE` AFTER UPDATE ON `penjualan_detail` FOR EACH ROW BEGIN
	DECLARE v_total_penjualan DECIMAL(10,2);
    SET v_total_penjualan = (select sum(sub_total) from penjualan_detail where id_penjualan = new.id_penjualan);
	update penjualan set total_penjualan = v_total_penjualan where id = new.id_penjualan;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `penjualan_detail_BEFORE_INSERT` BEFORE INSERT ON `penjualan_detail` FOR EACH ROW BEGIN
	DECLARE vbarang int;
    set vbarang = (SELECT harga_satuan FROM barang where id = new.id_barang);
    
    SET new.sub_total = (vbarang * new.jumlah_barang);
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `penjualan_detail_BEFORE_UPDATE` BEFORE UPDATE ON `penjualan_detail` FOR EACH ROW BEGIN

	DECLARE vbarang int;
    set vbarang = (SELECT harga_satuan FROM barang where id = new.id_barang);
    
    SET new.sub_total = (vbarang * new.jumlah_barang);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `email`) VALUES
(11, 'admin', '9f17c5e5a2045a2d20e5fde3721cbcb7', 'riiamri@gmail.com'),
(12, 'amri123', '32ba97374804d36c7974a3ec37f1af7d', 'amri@gmail.com'),
(13, 'admin123', '0192023a7bbd73250516f069df18b500', 'admin@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `penjualan`
--
ALTER TABLE `penjualan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `penjualan_detail`
--
ALTER TABLE `penjualan_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `barang`
--
ALTER TABLE `barang`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `penjualan`
--
ALTER TABLE `penjualan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `penjualan_detail`
--
ALTER TABLE `penjualan_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
